/* 
   Name: Michael Henson
   Date: 09/08/21
   Class: csc2710
   Path: ~/csc2710/program1/search.cpp

   Desc: This code implements the algorithms on arrays of random numbers. Add counters for both
searches that will output how many compares take place in the search. Add counters to the recursive
and iterative Fibonacci function that will output how often two numbers have been added together to
generate a number in the Fibonacci sequence.
*/

#include <iostream>
#include <ctime>
#include <time.h>
#include <cmath>

using namespace std;

//prototypes
void printData(int array[], int n);
int binSearch(const int array[], int search, int first, int last, bool &found);
int seqSearch(const int array[], int search, int n, bool &found);
void exchangeSort(int array[], int n);
long long int itFib(long long int n, int &counter);
long long int recFib(long long int n, int &counter);

int main()
{
   //initializing variables
   int n = 100; //number of elements in list array
   bool found = false;
   int search;
   int pos;
   int fibnum;
   int counter = 0;

   //load data into array
   int list[n];
   printData(list, n);

   cout << "Enter number for search: ";
   cin >> search;

   //sequentialSearch function
   pos = seqSearch(list, search, n, found);
   if(found == true)
      cout << search << " was found at position " << pos << endl;
   else
      cout << search << " was not found in the array." << endl;
   //exchangeSort function
   exchangeSort(list, n);
   cout << "The list has been sorted." << endl;
   //binarySearch function
   if(found == false)
   pos = binSearch(list, search, 0, n-1, found);
   if(found == true)
      cout << search << " was found at position " << pos << endl;
   else
      cout << search << " was not found in the array." << endl;
   //finding the nth fibonacci number
   cout << "Finding the nth fibonacci term.......,  enter n: ";
   cin >> fibnum;
   fibnum = abs(fibnum);
   cout << "The nth fibonnaci number (recursively) is: " << recFib(fibnum, counter) << ", found after ";
   cout << counter << " steps." << endl;
   counter = 0;
   cout << "The nth fibonnaci number (iteratively) is: " << itFib(fibnum, counter) << ", found after ";
   cout << counter << " steps." << endl;
   return 0;
}

//printData function to load the array 
void printData(int array[], int n)
{
   //random seed number generator
   srand(time(0));
   int random;
   //for loop that fills the array with random numbers
   for(int i=0; i<n; i++)
   {
      random = (rand() % 100);
      array[i] = random;
   }
}

//sequentialSearch function 
int seqSearch(const int array[], int search, int n, bool &found)
{
   int pos = 0;
   while(pos < n)
   {
      if(array[pos] == search)
      {
         found = true;
         return pos;
      }
      else
         pos++;
   }
   return 0;
}

//exchangeSort function
void exchangeSort(int array[], int n)
{
   int x, y;
   int temp;
   
   for(x=0; x<n; x++)
   {
      for(y=x+1; y<n; y++)
      {
         //swap
         if(array[x] > array[y])
         {
            temp = array[x];
            array[x] = array[y];
            array[y] = temp;
         }
      }
   }
   return;
}

//binarySearch function (recursive)
int binSearch(const int array[], int search, int first, int last, bool &found)
{
   if(last >= first)
   {
      int mid = first + (last-first)/2;
      if(array[mid] == search)
      {
         found = true;
         return mid;
      }
      else if(array[mid] < search)
         return binSearch(array, search, mid+1, last, found);
      else
         return binSearch(array, search, first, mid-1, found);
   }
   //return -1 if not found
   else
      return -1;
}

//recursive fibonacci function
long long int recFib(long long int n, int &counter)
{
   counter++;
   if(n <= 1)
      return n;
   else
      return (recFib(n-1, counter) + recFib(n-2, counter));
}

//iterative fibonacci function
long long int itFib(long long int n, int &counter)
{
   long long int prevprev, prev = 0, cur = 1;
   for(int i=1; i<n; i++)
   {
      prevprev = prev;
      prev = cur;
      cur = prevprev + prev;
      counter++;
   }
   return cur;
}

